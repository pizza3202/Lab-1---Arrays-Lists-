package edu.neu.mgen;

/**
 * Hello world!
 *
 */
public class HW7 
{
    public static void main( String[] args )
    {
        int[][] A = {{2,3,4},{3,4,5}};
        int[][] B = {{1,2},{3,4},{5,6}};
        int rowsOfA = A.length;
        int columnsOfA = A[0].length;
        int rowsOfB = B.length;
        int columnsOfB = B[0].length;
        int [][] C = new int[columnsOfB][rowsOfA];

        if (columnsOfA != rowsOfB){
            System.out.println("Error: cannot multiply the matrices >>> the rows of one matrice does not equal to the columns of the other matrice");
            return;
        }else {
            for (int i=0; i < rowsOfA; i++){
               for (int j=0; j < columnsOfB; j++){
                  for (int k=0; k < rowsOfB; k++){
                     C[i][j] += A[i][k] * B[k][j];
                  }
               }
            }
            System.out.println("The product of matrix A and matrix B is: ");
            for (int[] row: C){
               for(int element: row){
                  System.out.print(element + " ");
               }
               System.out.println();
            }
        }
    }
}
